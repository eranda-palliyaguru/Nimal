<footer class="main-footer">

    <div class="pull-right hidden-xs">

      <b>Version</b> 1.0

    </div>

    <strong>Copyright &copy; 2017 <a href="http://colorbiz.org">Color Biz</a>.</strong> 

  </footer>



  <!-- Control Sidebar -->
